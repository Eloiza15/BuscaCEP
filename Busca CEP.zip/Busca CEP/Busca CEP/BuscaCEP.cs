namespace Busca_CEP
{
    public partial class BuscaCEP : Form
    {
        public BuscaCEP()
        {
            InitializeComponent();
        }

        // Ao clicar no bot�o buscar cep
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                // Verifica o campo cep se est� preenchido
                if (!txtCep.Text.Equals(""))
                {
                    // Instanciando a classe Endereco, recebendo o m�todo buscar cep da classe serverCep
                    Endereco endereco = SeverCep.BuscarCEP(txtCep.Text); // Ser� retornado um objeto json com as informa��es

                    // Atribuindo as informa��es do endere�o nas labels
                    lblLogradouro.Text = endereco.Logradouro;
                    lblLocalidade.Text = endereco.Localidade;
                    lblBairro.Text = endereco.Bairro;
                    lblUF.Text = endereco.Uf;
                }
                else
                {
                    // Caso o campo estiver vazio, d� o aviso ao usu�rio
                    MessageBox.Show("Favor preencher campo cep para realizar a busca. ", "Erro � campo em branco", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    // Ap�s a mensagem foque no campo obrigat�rio
                    txtCep.Focus();
                }
            }
            catch (Exception ex)
            {
                // Ocorreu algum erro no c�digo acima
                MessageBox.Show("Erro ao buscar cep: " + ex.Message);
            }
        }

        //Ao clicar no X fecha a aplica��o
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
    }
}
