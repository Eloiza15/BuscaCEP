﻿namespace Busca_CEP
{
    partial class BuscaCEP
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BuscaCEP));
            PanelSuperior = new Panel();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            pictureBox3 = new PictureBox();
            panel1 = new Panel();
            lblUF = new Label();
            lblLocalidade = new Label();
            lblBairro = new Label();
            lblLogradouro = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            btnBuscar = new Button();
            label3 = new Label();
            label2 = new Label();
            txtCep = new MaskedTextBox();
            PanelSuperior.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // PanelSuperior
            // 
            PanelSuperior.BackColor = SystemColors.HotTrack;
            PanelSuperior.Controls.Add(pictureBox2);
            PanelSuperior.Controls.Add(pictureBox1);
            PanelSuperior.Controls.Add(label1);
            PanelSuperior.Dock = DockStyle.Top;
            PanelSuperior.Location = new Point(0, 0);
            PanelSuperior.Name = "PanelSuperior";
            PanelSuperior.Size = new Size(472, 38);
            PanelSuperior.TabIndex = 0;
            PanelSuperior.MouseDown += PanelSuperior_MouseDown;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(406, 8);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(24, 24);
            pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(436, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(24, 24);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(12, 8);
            label1.Name = "label1";
            label1.Size = new Size(142, 23);
            label1.TabIndex = 2;
            label1.Text = "Buscador de CEP";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(32, 33);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(171, 181);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 1;
            pictureBox3.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(txtCep);
            panel1.Controls.Add(lblUF);
            panel1.Controls.Add(lblLocalidade);
            panel1.Controls.Add(lblBairro);
            panel1.Controls.Add(lblLogradouro);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(btnBuscar);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox3);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 38);
            panel1.Name = "panel1";
            panel1.Size = new Size(472, 594);
            panel1.TabIndex = 2;
            // 
            // lblUF
            // 
            lblUF.AutoSize = true;
            lblUF.Font = new Font("Arial", 12F);
            lblUF.Location = new Point(228, 463);
            lblUF.Name = "lblUF";
            lblUF.Size = new Size(0, 18);
            lblUF.TabIndex = 14;
            // 
            // lblLocalidade
            // 
            lblLocalidade.AutoSize = true;
            lblLocalidade.Font = new Font("Arial", 12F);
            lblLocalidade.Location = new Point(228, 421);
            lblLocalidade.Name = "lblLocalidade";
            lblLocalidade.Size = new Size(0, 18);
            lblLocalidade.TabIndex = 13;
            // 
            // lblBairro
            // 
            lblBairro.AutoSize = true;
            lblBairro.Font = new Font("Arial", 12F);
            lblBairro.Location = new Point(228, 382);
            lblBairro.Name = "lblBairro";
            lblBairro.Size = new Size(0, 18);
            lblBairro.TabIndex = 12;
            // 
            // lblLogradouro
            // 
            lblLogradouro.AutoSize = true;
            lblLogradouro.Font = new Font("Arial", 12F);
            lblLogradouro.Location = new Point(228, 342);
            lblLogradouro.Name = "lblLogradouro";
            lblLogradouro.Size = new Size(0, 18);
            lblLogradouro.TabIndex = 11;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(94, 535);
            label8.Name = "label8";
            label8.Size = new Size(263, 19);
            label8.TabIndex = 10;
            label8.Text = "Desenvolvido Por: Eloiza Simões";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(32, 462);
            label7.Name = "label7";
            label7.Size = new Size(37, 19);
            label7.TabIndex = 9;
            label7.Text = "UF:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(32, 420);
            label6.Name = "label6";
            label6.Size = new Size(99, 19);
            label6.TabIndex = 8;
            label6.Text = "Localidade:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(32, 381);
            label5.Name = "label5";
            label5.Size = new Size(62, 19);
            label5.TabIndex = 7;
            label5.Text = "Bairro:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(32, 341);
            label4.Name = "label4";
            label4.Size = new Size(106, 19);
            label4.TabIndex = 6;
            label4.Text = "Logradouro:";
            // 
            // btnBuscar
            // 
            btnBuscar.BackColor = Color.Blue;
            btnBuscar.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBuscar.ForeColor = SystemColors.ButtonHighlight;
            btnBuscar.Location = new Point(276, 277);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(116, 35);
            btnBuscar.TabIndex = 5;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = false;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(32, 248);
            label3.Name = "label3";
            label3.Size = new Size(122, 19);
            label3.TabIndex = 3;
            label3.Text = "Informe o Cep:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.RoyalBlue;
            label2.Location = new Point(242, 110);
            label2.Name = "label2";
            label2.Size = new Size(168, 34);
            label2.TabIndex = 2;
            label2.Text = "Busca CEP";
            // 
            // txtCep
            // 
            txtCep.Location = new Point(32, 289);
            txtCep.Mask = "00000-000";
            txtCep.Name = "txtCep";
            txtCep.Size = new Size(196, 23);
            txtCep.TabIndex = 15;
            // 
            // BuscaCEP
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(472, 632);
            Controls.Add(panel1);
            Controls.Add(PanelSuperior);
            FormBorderStyle = FormBorderStyle.None;
            Name = "BuscaCEP";
            Text = "Form1";
            PanelSuperior.ResumeLayout(false);
            PanelSuperior.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel PanelSuperior;
        private PictureBox pictureBox3;
        private Panel panel1;
        private Label label1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Label label2;
        private Button btnBuscar;
        private Label label3;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label lblUF;
        private Label lblLocalidade;
        private Label lblBairro;
        private Label lblLogradouro;
        private Label label8;
        private MaskedTextBox txtCep;
    }
}
